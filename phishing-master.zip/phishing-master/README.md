# phishing
FOR Phishing(Without PHP)
__________________________
Phishing is an attempt to display onself as an authentic source in order to steal the credentials of the victim.

Phising attacks are common and it is not possible to distinguish the original site from the disguised one.

The only way you have is by looking at the URL.

I have Used Node.js, with express as a framework.
This code runs locally on your machine on port 3000.

It creates a file called logs.json that stores all the credentials of the users who attempt to register.

If you wish to replicate this, you need to have node.js installed.

You need to install express,ejs and body-parser as well.

Node.js can be downloaded from thier official site https://nodejs.org/en/download/

To install express, ejs and body-parser :npm install express,ejs,body-parser

FOR Phishing(Using PHP)
________________________
This can be hosted on a platform such as https://in.000webhost.com/ for free.

Unlike the former one, this can have serious consequenses as this will be available online.So, don't use it for your advantage.

Like the previous one, I have customized the login page, but one can add the contents as per one's choice.

One has to just right click on the page and click on "View Page source" and copy the source code to phishing.html

NOTE: One has to change the "action" attribute to "login_details.php".
